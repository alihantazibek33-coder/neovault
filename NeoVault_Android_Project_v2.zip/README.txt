NeoVault Android project
========================

Included:
- Offline Android WebView app wrapper
- Fictional collectible items (not real-world weapons)
- Direct-purchase shop (no randomized loot boxes)
- Coins, daily reward, inventory, item inspect/rotate, local save

To build an APK:
1. Open this project in Android Studio.
2. Wait for Gradle sync.
3. Select Build > Build APK(s).
4. APK usually appears under app/build/outputs/apk/debug/.

This ZIP is the Android project source, not a precompiled APK.
No external account or internet connection is required for the app itself.

Phone-only build option (GitHub Actions):
1. Create a new GitHub repository and upload the contents of this ZIP.
2. Open the repository's Actions tab.
3. Run "Build NeoVault APK" using Run workflow (or push to main).
4. When it finishes, open the workflow run and download the "NeoVault-debug-apk" artifact.
Note: GitHub account and repository setup are required. Keep the repository private if you don't want the source public.
